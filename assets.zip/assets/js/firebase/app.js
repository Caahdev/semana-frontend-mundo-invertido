  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/9.9.3/firebase-app.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  const firebaseConfig = {
    apiKey: "AIzaSyDyjBGxHb4H7D7n7vxTx49GoRyS2M6cZ2M",
    authDomain: "projeto-teste-79711.firebaseapp.com",
    projectId: "projeto-teste-79711",
    storageBucket: "projeto-teste-79711.appspot.com",
    messagingSenderId: "706018146128",
    appId: "1:706018146128:web:2e4fffa2c701c54a299e55"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  
  export default app